import { Component, OnInit } from '@angular/core';
import { Seller } from 'src/app/shared/models/seller';
import { SellerDealsForTodayService } from '../seller-deals-for-today.service';
import { Product } from 'src/app/shared/models/product';
import { SellerDeals } from 'src/app/shared/models/SellerDeals';

@Component({
  selector: 'app-seller-view-deals-for-today',
  templateUrl: './seller-view-deals-for-today.component.html',
  styleUrls: ['./seller-view-deals-for-today.component.css']
})
export class SellerViewDealsForTodayComponent implements OnInit {
  dealList: any[]

  seller: Seller
  displayProducts: Boolean
  productToBeViewed: Product
  p: number = 1
  productListLength: boolean=false
  successMessage:string=""
  errorMessage:string=""
  page: boolean = false
  constructor(private SellerDealsForTodayService: SellerDealsForTodayService) { }
  ngOnInit() {


    // this.productList = JSON.parse(sessionStorage.getItem("sellerProducts"));
    this.displayProducts = true
    this.seller = JSON.parse(sessionStorage.getItem("seller"));
    this.getProductDeals()


  }
  getProductDeals() {
    console.log(this.seller.emailId)
    this.SellerDealsForTodayService.getProductDeals(this.seller.emailId)
      .subscribe(dealList => {
    
        if (dealList.length > 10) {
          this.page = true
        }
        if(dealList.length>=1){
          this.productListLength=true
        }
        else{
          this.productListLength=false
        }
        let newDealList:any=[]
        for(let deal of dealList){
         let endDate  = deal.dealEndTime
         let endDateModified = endDate[0]+"-"+ endDate[1]+"-"+ endDate[2] + " "+ endDate[3]+":"+endDate[4]
        let todayDate = new Date()
          let endDateFinal=new Date(endDateModified)
        if(todayDate> endDateFinal){
           deal.isExpired=true
        }
        else{
          deal.isExpired= false
        }
         newDealList.push(deal)
        }
        this.dealList=newDealList
        console.log(this.dealList)
      }
      ,
        error=>{
          this.errorMessage=error.errorMessage
        
      }
      )
  }
  viewProductDetails(product: Product) {
    this.displayProducts = false
    this.productToBeViewed = product
    this.successMessage=""
    this.errorMessage=""
  }
  goBackToViewDeals() {
    this.displayProducts = true
    this.productToBeViewed = null
  }

  removeProduct(deal: any){
    console.log(deal)
    let newDeal:SellerDeals=new SellerDeals()
    newDeal.dealId=deal.dealId
    newDeal.dealDiscount=deal.dealDiscount
    newDeal.dealEndTime=null
    newDeal.product=deal.product
    newDeal.dealStartTime=null
    newDeal.seller=deal.seller
    newDeal.successMessage=""
    newDeal.errorMessage=""
    console.log(newDeal)
    this.SellerDealsForTodayService.removeProduct(newDeal)
    .subscribe(
      response=>{
       this.successMessage=response.successMessage
       
        let newDealList:any[]=[]
        for(let deal1 of this.dealList){

         let endDate  = deal1.dealEndTime
         let endDateModified = endDate[0]+"-"+ endDate[1]+"-"+ endDate[2] + " "+ endDate[3]+":"+endDate[4]
        let todayDate = new Date()
          let endDateFinal=new Date(endDateModified)
        if(todayDate> endDateFinal){
           deal1.isExpired=true
        }
        else{
          deal1.isExpired= false
        }
        if(deal1.dealId!=deal.dealId) {   
         newDealList.push(deal1)}
        }
        this.dealList=newDealList
        console.log(this.dealList)

        if (this.dealList.length > 10) {
          this.page = true
        }
        if(this.dealList.length>=1){
          this.productListLength=true
        }
        else{
          this.productListLength=false
        }
      },
        error=>{
          this.errorMessage=error.errorMessage
        
      }
     
    )

  }
}