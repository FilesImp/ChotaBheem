import { TestBed } from '@angular/core/testing';

import { SellerDealsAddProductsService } from './seller-deals-add-products.service';

describe('SellerDealsAddProductsService', () => {
  let service: SellerDealsAddProductsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SellerDealsAddProductsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
