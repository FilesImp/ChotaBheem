import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerDealsViewProductsComponent } from './seller-deals-view-products.component';

describe('SellerDealsViewProductsComponent', () => {
  let component: SellerDealsViewProductsComponent;
  let fixture: ComponentFixture<SellerDealsViewProductsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SellerDealsViewProductsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerDealsViewProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
