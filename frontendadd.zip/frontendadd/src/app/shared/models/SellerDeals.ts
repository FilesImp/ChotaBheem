import { Product } from './product';
import { Seller } from './seller';

export class SellerDeals{
    dealId:number
    product:Product
    dealDiscount:number
    dealStartTime:Date
    dealEndTime:Date
    seller:Seller
    successMessage:string
    errorMessage:string
}