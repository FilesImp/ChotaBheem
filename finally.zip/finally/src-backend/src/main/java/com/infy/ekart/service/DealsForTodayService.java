package com.infy.ekart.service;

import java.util.List;

import com.infy.ekart.dto.DealsForTodayDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.exception.EKartException;

public interface DealsForTodayService {

	Integer addProductsToDeal(DealsForTodayDTO dealsDTO) throws EKartException;
	
	List<ProductDTO> getProductWithoutDeals(String sellerEmailId,Integer pageNo) throws EKartException;
	
	List<DealsForTodayDTO> viewSellerDealsForToday(String sellerEmailId, Integer pageNo)throws EKartException;
	
	Integer removeProductFromDeals(Integer dealId) throws EKartException; 
	
	List<DealsForTodayDTO> getDealsForToday(Integer pageNo)throws EKartException;
	
}
