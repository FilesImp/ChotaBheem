import { Product } from './product';
import { Seller } from './seller';

export class SellerDeals{
    dealId:number
    productDTO:Product
    dealDiscount:number
    startDate:Date
    endDate:Date
    sellerDTO:Seller
    successMessage:string
    errorMessage:string
}