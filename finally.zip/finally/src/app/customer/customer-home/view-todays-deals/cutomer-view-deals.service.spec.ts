import { TestBed } from '@angular/core/testing';

import { CutomerViewDealsService } from './cutomer-view-deals.service';

describe('CutomerViewDealsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CutomerViewDealsService = TestBed.get(CutomerViewDealsService);
    expect(service).toBeTruthy();
  });
});
