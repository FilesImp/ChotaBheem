import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerViewDealsForTodayComponent } from './seller-view-deals-for-today.component';

describe('SellerViewDealsForTodayComponent', () => {
  let component: SellerViewDealsForTodayComponent;
  let fixture: ComponentFixture<SellerViewDealsForTodayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SellerViewDealsForTodayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerViewDealsForTodayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
