import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Product } from 'src/app/shared/models/product';
import { SellerDeals } from 'src/app/shared/models/SellerDeals';
import { CutomerViewDealsService } from './cutomer-view-deals.service';
import { ViewAllProductsService } from '../view-all-products/view-all-products.service';
//import { DealsComponent } from 'src/app/seller/seller-home/deals/deals.component';

@Component({
  selector: 'app-view-todays-deals',
  templateUrl: './view-todays-deals.component.html',
  styleUrls: ['./view-todays-deals.component.css']
})
export class ViewTodaysDealsComponent implements OnInit {

  p: number = 0;
  page: boolean = false;
  isProductSelected: boolean = false;
  selectedProduct: Product;
  productOnDeals: SellerDeals[];
  count: number = 0;
  errorMessage: string;
  successMessage: string;
  now = new Date();
  status: number[];
  pageLength:number;
  startDateTime:Date;
  endDateTime:Date;
  

  constructor(private customerViewDealsService: CutomerViewDealsService, private viewAllProductService: ViewAllProductsService) {
    setInterval(() => {
      this.now = new Date();
      this.setStatus();
    }
      , 5000);
  }

  ngOnInit() {
    this.successMessage = null;
    this.errorMessage = null;
    this.productOnDeals = null;

    this.getProductOnDealsForCustomer();
  }
  

  getProductOnDealsForCustomer() {
    this.status = [],


      this.customerViewDealsService.getProductOnDealsForCustomer(this.p).subscribe
        (
          (response) => {
            
console.log(response);
            this.viewAllProductService.getAllProducts()
              .subscribe(products => {
                let temp=[]
                for(let i=0; i<products.length;i++){
                  for(let j=0;j<response.length;j++){
                   // if(products[i].productId===response[j].productId){
                      temp.push({
                        dealId: response[j].dealId,
                       
                        //productId: response[j].productId,
                        dealDiscount: response[j].dealDiscount,
                        dealStartTime: response[j].dealStartTime,
                        dealEndTime: response[j].dealEndTime,
                        seller: response[j].seller,
                        errorMessage: response[j].errorMessage,
                        successMessage: response[j].successMessage,
                        productList: products[i]
                      });
                    
                  }
                }
                
                this.productOnDeals=temp;
                this.setStatus();

            if (this.productOnDeals.length > 10) {
              this.page = true;
            }
              }
              );
            
          },
          (response) => {
            this.errorMessage = <any>response;
            this.productOnDeals = null;
            this.successMessage = null;
          }
        )
  }

  setStatus() {
    let currTime = this.now;
    this.count = 0;
    for (var i = 0; i < this.productOnDeals.length; i++) {
      let startDateTime = new Date(this.productOnDeals[i].dealStartTime[0],
        this.productOnDeals[i].dealStartTime[1] - 1,
        this.productOnDeals[i].dealStartTime[2],
        this.productOnDeals[i].dealStartTime[3],
        this.productOnDeals[i].dealStartTime[4],
        0);

      let endDateTime = new Date(this.productOnDeals[i].dealEndTime[0],
        this.productOnDeals[i].dealEndTime[1] - 1,
        this.productOnDeals[i].dealEndTime[2],
        this.productOnDeals[i].dealEndTime[3],
        this.productOnDeals[i].dealEndTime[4],
        0);

      if (startDateTime.getTime() < currTime.getTime() && endDateTime.getTime() > currTime.getTime()) {
        this.status[i] = 1;
        this.count++;
      }
      else if (startDateTime.getTime() > currTime.getTime()) {
        this.status[i] = 2;
      }
      else if (endDateTime.getTime() < currTime.getTime()) {
        this.status[i] = 3;
      }


    }

  }

  setSelectedProduct(product: Product) {
    this.isProductSelected = true;
    this.successMessage = null;
    this.selectedProduct = product;
  }



  unsetSelectedProduct() {
    this.isProductSelected = false;
    this.selectedProduct = null;
  }

}
