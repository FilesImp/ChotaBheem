package com.infy.ekart.service.test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.dto.DealsForTodayDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.dto.SellerDTO;
import com.infy.ekart.entity.DealsForToday;
import com.infy.ekart.entity.Product;
import com.infy.ekart.entity.Seller;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.DealsForTodayRepository;
import com.infy.ekart.repository.ProductRepository;
import com.infy.ekart.repository.SellerRepository;
import com.infy.ekart.service.DealsForTodayService;
import com.infy.ekart.service.DealsForTodayServiceImpl;
import java.util.*;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;


//@SpringBootTest
public class DealsForTodayServiceTest {

//	@Mock
//	private DealsForTodayRepository dealsForTodayRepository;
//	
//	@Mock
//	private ProductRepository productRepository;
//	
//	@Mock
//	private SellerRepository sellerRepository;
//	
//	@InjectMocks
//	private DealsForTodayService dealsForTodayService = new DealsForTodayServiceImpl();
//	
//	@Test
//	void getProductWithoutDealsValidTest() throws EKartException{
//		String sellerEmailId="xyz@infosys.com";
//		Integer pageNo=0;
//		Pageable pageable=PageRequest.of(0, 10);
//		
//		List<Product> productList=new ArrayList<Product>();
//		Product product=new Product();
//		product.setProductId(1004);
//		
//		productList.add(product);
//		
//		Mockito.when(dealsForTodayRepository.productsWithoutDealForToday(sellerEmailId,pageable)).thenReturn(productList);
//		Assertions.assertNotNull(dealsForTodayService.getProductWithoutDeals(sellerEmailId,pageNo));
//		}
//	
//	@Test
//	void getProductWithoutDealsInValidTest() throws EKartException{
//		String sellerEmailId="xyz@infosys.com";
//		Integer pageNo=0;
//		Pageable pageable=PageRequest.of(0, 10);
//		
//		List<Product> productList=new ArrayList<Product>();
//		
//		
//		Mockito.when(dealsForTodayRepository.productsWithoutDealForToday(sellerEmailId,pageable)).thenReturn(productList);
//		EKartException e= Assertions.assertThrows(EKartException.class, ()->dealsForTodayService.getProductWithoutDeals(sellerEmailId, pageNo));
//		Assertions.assertEquals("DealsForToday.PRODUCTS_NOT_FOUND", e.getMessage());
//		}
//	
////	@Test
////	void addProductsToDealsForTodayValidTest() throws EKartException{
////		DealsForTodayDTO dealsForTodayDTO=new DealsForTodayDTO();
////		
////		SellerDTO sellerDTO=new SellerDTO();
////		sellerDTO.setEmailId("xyz@infosys.com");
////		sellerDTO.setName("xyz");
////		sellerDTO.setPassword("null");
////		sellerDTO.setConfirmNewPassword(null);
////		sellerDTO.setNewPassword(null);
////		sellerDTO.setPhoneNumber("7586923584");
////		sellerDTO.setAddress("Plot no:62");
////		sellerDTO.setErrorMessage(null);
////		sellerDTO.setProducts(null);
////		
////		ProductDTO productDTO=new ProductDTO();
////		productDTO.setProductId(1004);
////		productDTO.setName("Bot E5s Plus");
////		productDTO.setDescription("smart phone with (13+13)MP rear camera and 8MP front camera, 4GB RAM");
////		productDTO.setCategory("Electronics - Mmobile");
////		productDTO.setBrand("Notbot");
////		productDTO.setPrice(16000.0);
////		productDTO.setDiscount(150.0);
////		productDTO.setQuantity(5);
////		productDTO.setErrorMessage(null);
////		productDTO.setSuccessMessage(null);
////		productDTO.setSellerEmailId("xyz@infosys.com");
////		
////		dealsForTodayDTO.setSellerDTO(sellerDTO);
////		dealsForTodayDTO.setProductDTO(productDTO);
////		dealsForTodayDTO.setDealDiscount(50.0);
////		dealsForTodayDTO.setStartDate(LocalDateTime.now());
////		dealsForTodayDTO.setEndDate(LocalDateTime.of(2021,9,30,12,0,0));
////		dealsForTodayDTO.setDealId(504117);
////		dealsForTodayDTO.setSuccessMessage(null);
////		
////		Seller seller = new Seller();
////		seller.setEmailId(dealsForTodayDTO.getSellerDTO().getEmailId());
////		
////		Product product=new Product();
////		product.setProductId(dealsForTodayDTO.getProductDTO().getProductId());
////		
////		DealsForToday dealsForToday= new DealsForToday();
////		dealsForToday.setSeller(seller);
////		dealsForToday.setProduct(product);
////		dealsForToday.setDealDiscount(dealsForToday.getDealDiscount());
////		dealsForToday.setStartDate(dealsForToday.getStartDate());
////		dealsForToday.setEndDate(dealsForToday.getEndDate());
////		dealsForToday.setDealId(dealsForToday.getDealId());
////		
////		Mockito.when(sellerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(seller));
////		Mockito.when(productRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(product));
////		Mockito.when(dealsForTodayRepository.save(Mockito.any())).thenReturn(dealsForToday);
////		Assertions.assertDoesNotThrow(()->dealsForTodayService.addProductsToDeal(dealsForTodayDTO));
////		}
//	
//	@Test
//	void addProductsToDealsForTodayInvalidSellerTest() throws EKartException{
//		DealsForTodayDTO dealsForTodayDTO=new DealsForTodayDTO();
//		SellerDTO sellerDTO=new SellerDTO();
//		sellerDTO.setEmailId("abc@infosys.com");
//		ProductDTO productDTO=new ProductDTO();
//		productDTO.setProductId(1234);
//		
//		dealsForTodayDTO.setSellerDTO(sellerDTO);
//		dealsForTodayDTO.setProductDTO(productDTO);
//		
//		Product product=new Product();
//		product.setProductId(dealsForTodayDTO.getProductDTO().getProductId());
//		
//		Mockito.when(sellerRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
//		Mockito.when(productRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(product));
//		EKartException e=Assertions.assertThrows(EKartException.class,()->dealsForTodayService.addProductsToDeal(dealsForTodayDTO));
//		Assertions.assertEquals("Service.SELLER_NOT_FOUND", e.getMessage());
//		
//	}
//	
//	@Test
//	void addProductsToDealsForTodayInvalidProductTest() throws EKartException{
//		DealsForTodayDTO dealsForTodayDTO=new DealsForTodayDTO();
//		SellerDTO sellerDTO=new SellerDTO();
//		sellerDTO.setEmailId("abc@infosys.com");
//		
//		ProductDTO productDTO=new ProductDTO();
//		productDTO.setProductId(1234);
//		
//		dealsForTodayDTO.setSellerDTO(sellerDTO);
//		dealsForTodayDTO.setProductDTO(productDTO);
//		
//		Seller seller=new Seller();
//		seller.setEmailId(dealsForTodayDTO.getSellerDTO().getEmailId());
//		
//		Mockito.when(productRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
//		Mockito.when(sellerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(seller));
//		EKartException e=Assertions.assertThrows(EKartException.class,()->dealsForTodayService.addProductsToDeal(dealsForTodayDTO));
//		Assertions.assertEquals("Service.PRODUCT_NOT_FOUND", e.getMessage());
//		
//	}
//	
//	@Test
//	void viewSellerDealsForTodayValidTest() throws EKartException{
//		String sellerEmailId="xyz@infosys.com";
//		List<DealsForToday> list=new ArrayList<>();
//		DealsForToday dealsForToday=new DealsForToday();
//		dealsForToday.setDealId(504117);
//		
//		Seller seller =new Seller();
//		seller.setEmailId(sellerEmailId);
//		dealsForToday.setSeller(seller);
//		
//		Product product =new Product();
//		product.setProductId(1002);
//		dealsForToday.setProduct(product);
//		
//		list.add(dealsForToday);
//		Integer pageNo=0;
//		Pageable pageable=PageRequest.of(0, 10);
//		
//		Mockito.when(dealsForTodayRepository.findBySellerEmailId(sellerEmailId,pageable)).thenReturn(list);
//		Assertions.assertNotNull(dealsForTodayService.viewSellerDealsForToday(sellerEmailId,pageNo));
//		
//		
//	}
//	@Test
//	void viewSellerDealsForTodayInvalidTest() throws EKartException{
//		String sellerEmailId="xyz@infosys.com";
//		List<DealsForToday> list=new ArrayList<>();
//		Integer pageNo=0;
//		Pageable pageable=PageRequest.of(0, 10);
//		
//		Mockito.when(dealsForTodayRepository.findBySellerEmailId(sellerEmailId,pageable)).thenReturn(list);
//		EKartException e=Assertions.assertThrows(EKartException.class,()->dealsForTodayService.viewSellerDealsForToday(sellerEmailId,pageNo));
//
//		Assertions.assertEquals("DealsForToday.NO_DEALS_FOUND",e.getMessage());
//	}
//	
//	@Test
//	void getDealsForValidTest() throws EKartException{
//		//LocalDateTime startDate=LocalDateTime.of(LocalDate.now(), LocalTime.of(0, 0, 0));
//		//LocalDateTime endDate=LocalDateTime.of(LocalDate.now().plusDays(1), LocalTime.of(0, 0, 0));
//		
//		List<DealsForToday> list=new ArrayList<>();
//		DealsForToday dealsForToday=new DealsForToday();
//		dealsForToday.setDealId(504821);
//		
//		Seller seller =new Seller();
//		seller.setEmailId("xyz@infosys.com");
//		dealsForToday.setSeller(seller);
//		
//		Product product =new Product();
//		product.setProductId(1002);
//		dealsForToday.setProduct(product);
//		
//		list.add(dealsForToday);
//		//Integer pageNo=0;
//		Page<DealsForToday> page=new PageImpl<>(list);
//		Pageable pageable=PageRequest.of(1, 10);
//		
//		Mockito.when(dealsForTodayRepository.findAll(pageable)).thenReturn(page);
//		Assertions.assertNotNull(dealsForTodayService.getDealsForToday(1));
//		
//	}
//	@Test
//	void getDealsForTodayInValidTest() throws EKartException{
//		//LocalDateTime startDate=LocalDateTime.of(LocalDate.now(), LocalTime.of(0, 0, 0));
//		//LocalDateTime endDate=LocalDateTime.of(LocalDate.now().plusDays(1), LocalTime.of(0, 0, 0));
//		List<DealsForToday> list=new ArrayList<>();
//		Page<DealsForToday> page=new PageImpl<>(list);
//		
//		//Integer pageNo=0;
//		Pageable pageable=PageRequest.of(0, 10);
//		
//		Mockito.when(dealsForTodayRepository.findAll(pageable)).thenReturn(page);
//		EKartException e=Assertions.assertThrows(EKartException.class,()->dealsForTodayService.getDealsForToday(1));
//
//		Assertions.assertEquals("DealsForToday.NO_DEALS_FOUND",e.getMessage());
//	}
//	
	
}
