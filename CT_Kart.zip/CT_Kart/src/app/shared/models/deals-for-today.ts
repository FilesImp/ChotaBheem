import { Product } from './product';
import { Seller } from './seller';

export class DealsForToday{
    dealId: number;
    productDTO: Product;
    dealDiscount: number;
    dealStartsAt: Date;
    dealEndsAt: Date;
    SellerDTO: Seller;
    errorMessage: string;
    successMessage: string;
}