import { Injectable } from '@angular/core';
import { HttpHandler, HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { catchError } from 'rxjs/operators';
import { Product } from 'src/app/shared/models/product';
import { Seller } from 'src/app/shared/models/seller';

@Injectable({
  providedIn: 'root'
})
export class SellerDealsAddProductsService {

  private headers=new HttpHeaders({'Content-Type':'application/json'});
  constructor(private httpClient:HttpClient) { }

  productsCurrentlyBeingSold(emailId: String, pageNo: number): Observable<Product[]>
  {
    const url=environment.dealsForTodayAPIUrl + "/withoutDealsForToday"+"/"+emailId+"/"+pageNo;
    return this.httpClient.get<Product[]>(url).pipe(catchError(this.handleError));
  }

  addProductToDeals(productDTO:Product, dealDiscount:number, dealStartsAt:string, dealEndsAt:string,sellerDTO:Seller):Observable<any>
  {
    const url=environment.dealsForTodayAPIUrl + "/dealsForToday";
    return this.httpClient.post<any>(url,{productDTO,dealDiscount,dealStartsAt,dealEndsAt,sellerDTO},
      {headers:this.headers,responseType:'text' as'json'}).pipe(catchError(this.handleError));
 
  }

  private handleError(err: HttpErrorResponse){
    console.log(err)
    let errMsg: string = '';
    if(err.error instanceof Error){
      errMsg = err.error.message;
      console.log(errMsg)
    }
    else if(typeof err.error == 'string'){
      errMsg = JSON.parse(err.error).errorMessage
    }
    else{
      if(err.status == 0){
        errMsg = "A Connection to back end can not be established.";
      }else{
        errMsg = err.error.message;
      }
    }
    return throwError(errMsg);
  }
}
