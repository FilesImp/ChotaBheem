import { TestBed } from '@angular/core/testing';

import { DealsForTodayServiceService } from './deals-for-today-service.service';

describe('DealsForTodayServiceService', () => {
  let service: DealsForTodayServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DealsForTodayServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
