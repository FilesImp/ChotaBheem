import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { DealsForToday } from 'src/app/shared/models/deals-for-today';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/internal/operators/catchError';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SellerDealsViewProductsService {
  private headers=new HttpHeaders({'Content-Type':'application/json'});
  constructor(private httpClient:HttpClient) { }

  getProductsInDealList(sellerEmailId:string, pageNo:number): Observable<DealsForToday[]>
  {
    const url=environment.dealsForTodayAPIUrl + "/withoutDealsForToday"+"/"+sellerEmailId+"/"+pageNo;
    return this.httpClient.get<DealsForToday[]>(url).pipe(catchError(this.handleError))
  }  

  private handleError(err: HttpErrorResponse){
    console.log(err)
    let errMsg: string = '';
    if(err.error instanceof Error){
      errMsg = err.error.message;
      console.log(errMsg)
    }
    else if(typeof err.error == 'string'){
      errMsg = JSON.parse(err.error).errorMessage
    }
    else{
      if(err.status == 0){
        errMsg = "A Connection to back end can not be established.";
      }else{
        errMsg = err.error.message;
      }
    }
    return throwError(errMsg);
  }

}
