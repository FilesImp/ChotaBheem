import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deals-today',
  templateUrl: './deals-today.component.html',
  styleUrls: ['./deals-today.component.css']
})
export class DealsTodayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
