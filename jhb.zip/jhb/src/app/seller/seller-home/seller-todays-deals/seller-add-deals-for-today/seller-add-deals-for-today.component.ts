import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/shared/models/product';
import { Seller } from 'src/app/shared/models/seller';
import { SellerDealsForTodayService } from '../seller-deals-for-today.service';
import { FormGroup, FormBuilder, Validators, FormControl, AbstractControl } from '@angular/forms';
import { DealDateValidator } from 'src/app/shared/validators/deal-date-validator';
import { SellerDeals } from 'src/app/shared/models/SellerDeals';


@Component({
  selector: 'app-seller-add-deals-for-today',
  templateUrl: './seller-add-deals-for-today.component.html',
  styleUrls: ['./seller-add-deals-for-today.component.css']
})
export class SellerAddDealsForTodayComponent implements OnInit {

  productList: Product[]
  productCategoryList: string[]
  seller: Seller
  displayProducts: Boolean
  product: Product
  successMessage: string
  errorMessage: string
  addProductsToDealForm: FormGroup
  productListLength: boolean=false
  p: number = 1

  page: boolean = false

  constructor(private fb: FormBuilder, private SellerDealsForTodayService: SellerDealsForTodayService) { }

  ngOnInit() {
    this.displayProducts = true
    this.seller = JSON.parse(sessionStorage.getItem("seller"));
    this.getProductsNotOnDeals()


  }
  getProductsNotOnDeals() {
    console.log(this.seller.emailId)
    this.SellerDealsForTodayService.getProductsNotOnDeals(this.seller.emailId).subscribe(productList => {
      this.productList = productList
      console.log(productList)
      if (productList.length >= 1) {
        this.productListLength = true
      }
      else{
        this.productListLength=false
      }
    }
    ,
    error=>{this.errorMessage=error.errorMessage}
    )
  }
  showFormToAddDeal(product: Product) {
    this.product = product
    this.displayProducts = false
    this.createForm()
    console.log(this.addProductsToDealForm.value)
  }
  createForm() {
    this.successMessage=this.errorMessage=null
    this.addProductsToDealForm = this.fb.group({


      dealStartTime: ["",[ Validators.required,DealDateValidator.afterToday]],
      dealEndTime: ["",[ Validators.required,DealDateValidator.afterToday]],
      dealDiscount: [1, [Validators.required, Validators.min(0.1),Validators.max(100)]],

    },{
      validators:[DealDateValidator.sameDate,DealDateValidator.endDateValidator]
    });
  }


  addProductToDeals() {
    const deal:SellerDeals = this.addProductsToDealForm.value  as SellerDeals
    deal.product = this.product
    deal.seller = this.seller
    deal.successMessage=""
    deal.errorMessage=""
    this.SellerDealsForTodayService.addProductToDeal(deal).subscribe(
      response=>{this.successMessage=response.successMessage
        this.displayProducts=true
        this.getProductsNotOnDeals()
      },
        error=>{this.errorMessage=error.errorMessage}
      
      )
  }
}