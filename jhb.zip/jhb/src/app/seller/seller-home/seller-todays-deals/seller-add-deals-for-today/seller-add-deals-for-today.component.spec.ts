import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SellerAddDealsForTodayComponent } from './seller-add-deals-for-today.component';

describe('SellerAddDealsForTodayComponent', () => {
  let component: SellerAddDealsForTodayComponent;
  let fixture: ComponentFixture<SellerAddDealsForTodayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SellerAddDealsForTodayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SellerAddDealsForTodayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
