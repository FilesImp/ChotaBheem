import { TestBed } from '@angular/core/testing';

import { SellerDealsViewProductsService } from './seller-deals-view-products.service';

describe('SellerDealsViewProductsService', () => {
  let service: SellerDealsViewProductsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SellerDealsViewProductsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
