import { TestBed } from '@angular/core/testing';

import { DealsTodayService } from './deals-today.service';

describe('DealsTodayService', () => {
  let service: DealsTodayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DealsTodayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
