import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deals-for-today',
  templateUrl: './deals-for-today.component.html',
  styleUrls: ['./deals-for-today.component.css']
})
export class DealsForTodayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
