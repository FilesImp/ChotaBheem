import { Component, OnInit, Input } from '@angular/core';
import { Seller } from 'src/app/shared/models/seller';
import { Product } from 'src/app/shared/models/product';
import { DealsForToday } from 'src/app/shared/models/deals-for-today';
import { SellerDealsViewProductsService } from './seller-deals-view-products.service';

@Component({
  selector: 'app-seller-deals-view-products',
  templateUrl: './seller-deals-view-products.component.html',
  styleUrls: ['./seller-deals-view-products.component.css']
})
export class SellerDealsViewProductsComponent implements OnInit {

  seller: Seller;
  successMessage: String="";
  errorMessage: String="";
  product;
  p:number=0;
  page: boolean=false;
  submitted: boolean=false;
  pageLength: any;

  @Input()
  receiveProduct: Product;
  productsList: Product[];
  productDeatils: Product;
  dealProductDetails: DealsForToday;
  displayProducts: Boolean;
  productsInDealList: DealsForToday[];
  productsInDeal: DealsForToday[];
  productsAvailable: boolean;



  constructor(private sellerViewDealProducts: SellerDealsViewProductsService) { }

  ngOnInit(): void {
    this.productsList = JSON.parse(sessionStorage.getItem("sellerProducts"));

    this.displayProducts = true;
    this.seller = JSON.parse(sessionStorage.getItem("seller"));
    this.sellerViewDealProducts.getProductsInDealList(this.seller.emailId,0)
      .subscribe(response=>{
      console.log(response)
      this.productsInDealList = response;
      this.displayProducts = this.productsInDealList.length != 0;
      this.page = this.productsInDealList.length != 0;
      this.productsAvailable = this.productsInDealList.length == 0;

    })

    this.getProductsInDealList()
  }
  getProductsInDealList(){
    this.sellerViewDealProducts.getProductsInDealList(this.seller.emailId,this.p)
      .subscribe(response=>{
        console.log(response)
        this.productsInDealList = response;
        this.displayProducts = this.productsInDealList.length != 0;
        this.page = this.productsInDealList.length != 0;

      })
  }
  
  isDealActive(productsInDeal:DealsForToday):boolean{
    let sysDateTime:Date = new Date();
    let dealEndsAt:Date = new Date(productsInDeal.dealEndsAt[0],productsInDeal.dealEndsAt[1]-1,
      productsInDeal.dealEndsAt[2],productsInDeal.dealEndsAt[3],productsInDeal.dealEndsAt[4],0);
    if(dealEndsAt<sysDateTime)
      return false;
    return true;
  }

  viewProductDetails(productId:number){
    console.log(productId)
    console.log(this.productsList)
    this.productDeatils = new Product;
    for(let product of this.productsList){
      if(productId == product.productId)
      {
        this.productDeatils = product;

      }
      console.log(this.productDeatils)
      console.log(this.productsInDealList)
    }
    this.displayProducts = false;
  }

  viewDealProduct(prod:number){
    console.log(prod)
    console.log(this.productsList)
    this.productDeatils = new Product;
    for(let product of this.productsList){
      if(prod == product.productId)
      {
        this.productDeatils = product;
        console.log(this.productDeatils)

      }

    }
  } 
  goToPrevious(){
    if(this.p>0){
      this.p--;
      this.getProductsInDealList();
    }
  }

  goToNext(){
    if(this.productsInDealList.length==10){

      this.p++;
      this.getProductsInDealList();
    }
    else{
      this.page = true;
    }


  }
  
}
