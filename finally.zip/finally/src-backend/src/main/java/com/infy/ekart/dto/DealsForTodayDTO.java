package com.infy.ekart.dto;

import java.time.LocalDateTime;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;

public class DealsForTodayDTO {

	private Integer dealId;
	@NotNull(message = "{dealdiscount.absent}")
	private Double dealDiscount;
	
	@NotNull(message = "{startdate.absent}")
	@Future(message = "{DealsForToday.invalid.startdate}")
	private LocalDateTime startDate;
	
	@NotNull(message = "{enddate.absent}")
	@Future(message = "{DealsForToday.invalid.enddate}")
	private LocalDateTime endDate;
	
	@NotNull
	private ProductDTO productDTO;
	
	@NotNull
	private SellerDTO sellerDTO;

	public Integer getDealId() {
		return dealId;
	}

	public void setDealId(Integer dealId) {
		this.dealId = dealId;
	}

	public Double getDealDiscount() {
		return dealDiscount;
	}

	public void setDealDiscount(Double dealDiscount) {
		this.dealDiscount = dealDiscount;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	public ProductDTO getProductDTO() {
		return productDTO;
	}

	public void setProductDTO(ProductDTO productDTO) {
		this.productDTO = productDTO;
	}

	public SellerDTO getSellerDTO() {
		return sellerDTO;
	}

	public void setSellerDTO(SellerDTO sellerDTO) {
		this.sellerDTO = sellerDTO;
	}
	
	
	
	
}
