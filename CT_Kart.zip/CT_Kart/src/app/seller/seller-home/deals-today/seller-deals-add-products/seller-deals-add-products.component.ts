import { Component, OnInit } from '@angular/core';
import { Seller } from 'src/app/shared/models/seller';
import { Product } from 'src/app/shared/models/product';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SellerDealsAddProductsService } from './seller-deals-add-products.service';
import { SellerProductsService } from '../../products/seller-products/seller-products.service';

@Component({
  selector: 'app-seller-deals-add-products',
  templateUrl: './seller-deals-add-products.component.html',
  styleUrls: ['./seller-deals-add-products.component.css']
})
export class SellerDealsAddProductsComponent implements OnInit {

  seller: Seller
  successMessage: String="";
  errorMessage: String="";
  productsNotInDealList: Product[]
  p:number=0;
  page: boolean=false
  productToAdd: Product
  productAddForm: FormGroup
  displayProducts: Boolean
  submitted: Boolean
  productId: number
  dealStartsAt: string
  dealEndsAt: string
  sellerEmailId: string
  dealDiscount: number
  

  constructor(private formBuilder: FormBuilder, 
    private dealsSellerAddProductService:SellerDealsAddProductsService,
    private sellerService: SellerProductsService) { }

  ngOnInit(): void {
    this.seller = JSON.parse(sessionStorage.getItem("seller"));
    this.productsCurrentlyBeingSold()
  }

  productsCurrentlyBeingSold(){
    this.dealsSellerAddProductService.productsCurrentlyBeingSold(this.seller.emailId,this.p)
      .subscribe(productsNotInDealList => {
        this.productsNotInDealList = productsNotInDealList
        if(this.productsNotInDealList.length >0){
          this.page=true
        }
      console.log(this.productsNotInDealList)
      console.log(this.seller)
      })
    this.displayProducts = true
    this.submitted = false
  }

  add(product: Product){
    this.displayProducts = false
    this.submitted = true
    this.productToAdd = product
    this.sellerEmailId = this.seller.emailId
    console.log(this.sellerEmailId)

    this.productId = this.productToAdd.productId
    console.log(this.productId)
    this.successMessage = ''
    this.errorMessage = ''
    this.createForm()
    console.log(this.productToAdd)
  }

  createForm(){
    this.productAddForm = this.formBuilder.group({
      dealStartsTime: ["", Validators.required],
      dealEndsTime: ["", Validators.required],
      discount: ["",Validators.required]
    })
  }

  AddProductToDeal(){
    this.dealStartsAt = this.productAddForm.value.dealStartTime
    this.dealEndsAt = this.productAddForm.value.dealEndTime
    this.dealDiscount = this.productAddForm.value.discount
    this.dealsSellerAddProductService.addProductToDeals(this.
      productToAdd,this.dealDiscount, this.dealStartsAt, this.dealEndsAt,
      this.seller).subscribe((response)=>{
        this.successMessage = response
        this.submitted = false
      },
      error => {
        this.errorMessage = <any>error
      })
    }

    goToPrevious(){
      if(this.p>0){
        this.p--
        this.productsCurrentlyBeingSold();
      }
    }

    goToNext(){
      if(this.productsNotInDealList.length==10){
        this.p++
        this.productsCurrentlyBeingSold();
      }
      else{
        this.page = true;
      }
  }
}
