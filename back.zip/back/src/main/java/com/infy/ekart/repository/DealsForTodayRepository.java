package com.infy.ekart.repository;


import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.infy.ekart.entity.DealsForToday;
import com.infy.ekart.entity.Product;

public interface DealsForTodayRepository extends PagingAndSortingRepository<DealsForToday, Integer>{
	@Query("select c from Product c where  c.productId not in (select d.product.productId from DealsForToday d where d.seller.emailId=?1)")
	List<Product> productsWithoutDealForToday(String sellerEmailId,Pageable page);
	
	List<DealsForToday> findBySellerEmailId(String emailId,Pageable p);
	//public Page<DealsForToday> findAll(Pageable pageable);
	
	@Query("select d from DealsForToday d where d.startDate between ?1 and ?2 or d.endDate between ?1 and ?2")
	List<DealsForToday> customerDealsForToday(LocalDateTime starts,LocalDateTime ends,Pageable p);

}
