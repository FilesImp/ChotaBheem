import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/shared/models/product';
import { Seller } from 'src/app/shared/models/seller';
import { SellerDealsForTodayService } from '../seller-deals-for-today.service';
import { FormGroup, FormBuilder, Validators, FormControl, AbstractControl } from '@angular/forms';
import { DealDateValidator } from 'src/app/shared/validators/deal-date-validator';
import { SellerDeals } from 'src/app/shared/models/SellerDeals';


@Component({
  selector: 'app-seller-add-deals-for-today',
  templateUrl: './seller-add-deals-for-today.component.html',
  styleUrls: ['./seller-add-deals-for-today.component.css']
})
export class SellerAddDealsForTodayComponent implements OnInit {

  productList: Product[]
  productCategoryList: string[]
  seller: Seller
  displayProducts: Boolean
  product: Product
  successMessage: string
  errorMessage: string
  addProductsToDealForm: FormGroup
  productListLength: boolean=false
  p: number = 1
  pageNo:number=0

  
  productsNotInDealList: Product[]
 
  page: boolean=false
  productToAdd: Product
  productAddForm: FormGroup
 
  submitted: Boolean
  productId: number
  dealStartsAt: string
  dealEndsAt: string
  sellerEmailId: string
  dealDiscount: number

 

  constructor(private fb: FormBuilder, private SellerDealsForTodayService: SellerDealsForTodayService) { }

  ngOnInit() {
    this.displayProducts = true
    this.seller = JSON.parse(sessionStorage.getItem("seller"));
    this.getProductsNotOnDeals()


  }
  getProductsNotOnDeals() {
    console.log(this.seller.emailId)
    this.SellerDealsForTodayService.getProductsNotOnDeals(this.seller.emailId,this.pageNo).subscribe(productList => {
      this.productList = productList
      console.log(productList)
      if (productList.length >= 1) {
        this.productListLength = true
      }
      else{
        this.productListLength=false
      }
    }
    ,
    error=>{this.errorMessage=error.errorMessage}
    )
  }
  showFormToAddDeal(product: Product) {
    this.product = product
    this.displayProducts = true
    this.createForm()
    console.log(this.addProductsToDealForm.value)
  }
  createForm() {
    this.successMessage=this.errorMessage=null
    this.addProductsToDealForm = this.fb.group({


      dealStartTime: ["",[ Validators.required,DealDateValidator.afterToday]],
      dealEndTime: ["",[ Validators.required,DealDateValidator.afterToday]],
      dealDiscount: [1, [Validators.required, Validators.min(0.1),Validators.max(100)]],

    },{
      validators:[DealDateValidator.sameDate,DealDateValidator.endDateValidator]
    });
  }


  addProductToDeals() {
    const deal:SellerDeals = this.addProductsToDealForm.value  as SellerDeals
    deal.product = this.product
    deal.seller = this.seller
    deal.successMessage=""
    deal.errorMessage=""
    this.SellerDealsForTodayService.addProductToDeal(deal).subscribe(
      response=>{this.successMessage=response.successMessage
        this.displayProducts=true
        this.getProductsNotOnDeals()
      },
        error=>{this.errorMessage=error.errorMessage}
      
      )
  }

  // add(product: Product){
  //   this.displayProducts = false
  //   this.submitted = true
  //   this.productToAdd = product
  //   this.sellerEmailId = this.seller.emailId
  //   console.log(this.sellerEmailId)

  //   this.productId = this.productToAdd.productId
  //   console.log(this.productId)
  //   this.successMessage = ''
  //   this.errorMessage = ''
  //   this.createForm()
  //   console.log(this.productToAdd)
  // }

  // createForm(){
  //   this.addProductsToDealForm = this.fb.group({
  //     dealStartsTime: ["", Validators.required],
  //     dealEndsTime: ["", Validators.required],
  //     discount: ["",Validators.required]
  //   })
  // }

  // AddProductToDeal(){
  //   this.dealStartsAt = this.productAddForm.value.dealStartTime
  //   this.dealEndsAt = this.productAddForm.value.dealEndTime
  //   this.dealDiscount = this.productAddForm.value.discount
  //   const deal:SellerDeals = this.addProductsToDealForm.value  as SellerDeals
  //   deal.product = this.product
  //   deal.seller = this.seller
  //   deal.successMessage=""
  //   deal.errorMessage=""
  //   this.SellerDealsForTodayService.addProductToDeal(deal).subscribe(
  //         response=>{this.successMessage=response.successMessage
  //           this.displayProducts=true
  //           this.getProductsNotOnDeals()
  //         },
  //     error => {
  //       this.errorMessage = <any>error
  //     })
  //   }
















}