import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dateTimeEdit'
})
export class DateTimeEditPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    let v:string;
    if(value[4]==0){
      value[4]="00"
    }
    
    return value[2]+"-"+value[1]+"-"+value[0] + " " + value[3]+":"+ value[4];
  }

}
